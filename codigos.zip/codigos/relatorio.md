# c-lista-atividades



Lista de atividades sobre a linguagem C
1-8: Marcos
9-16: Marcos vini.
17-24: Marcell Henrique 
25-32: Luiz Henrique 
33-40: Manoel



![1](https://github.com/marcos-henri/c-lista-atividades/assets/112349436/096526d7-11fd-4526-8992-8d8e89a5670c)
![2](https://github.com/marcos-henri/c-lista-atividades/assets/112349436/cd2e2d0f-8968-48d9-aa66-d9ccd1caec37)
![3](https://github.com/marcos-henri/c-lista-atividades/assets/112349436/72cf4403-526f-4f2f-ace2-983e8f775a03)
![4](https://github.com/marcos-henri/c-lista-atividades/assets/112349436/ff1d9bf5-ad94-48a4-ac9a-7809adcc74ff)
